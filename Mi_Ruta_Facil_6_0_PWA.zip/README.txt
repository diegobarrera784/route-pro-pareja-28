MI RUTA FÁCIL 6.0 — INSTALACIÓN

Sube estos 5 archivos juntos a la raíz de GitHub Pages:
index.html
manifest.json
sw.js
icon-180.png
icon-512.png

iPhone: Safari > Compartir > Agregar a pantalla de inicio.
Android: Chrome > ⋮ > Instalar aplicación / Agregar a pantalla de inicio.

Conserva la versión 5.9 como respaldo hasta terminar las pruebas.
